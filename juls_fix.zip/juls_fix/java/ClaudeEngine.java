package mx.dateseg.juls.core;

import android.content.Context;

public class ClaudeEngine {
    public ClaudeEngine(Context context) {}
    public void ask(String prompt, Callback cb) {
        if (cb != null) cb.onResponse("Usa la app web para chatear con JULS");
    }
    public interface Callback { void onResponse(String r); }
}
