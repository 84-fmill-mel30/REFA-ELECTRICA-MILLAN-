package mx.dateseg.juls.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import mx.dateseg.juls.R;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Esta pantalla está integrada en JULS_FINAL (index.html)
        // Regresar a MainActivity
        finish();
    }
}
