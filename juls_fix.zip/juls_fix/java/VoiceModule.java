package mx.dateseg.juls.core;

import android.content.Context;

public class VoiceModule {
    public VoiceModule(Context context) {}
    public void start() {}
    public void stop() {}
}
