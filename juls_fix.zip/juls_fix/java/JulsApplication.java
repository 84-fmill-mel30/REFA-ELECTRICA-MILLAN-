package mx.dateseg.juls;

import android.app.Application;

public class JulsApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
